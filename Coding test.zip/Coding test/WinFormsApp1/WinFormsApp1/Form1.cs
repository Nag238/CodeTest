﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            DataTable dt = new DataTable("Treetbl");
            DataSet ds = new DataSet();
            //dt.Columns.Add("ID", typeof(int));
            //dt.Columns.Add("ParentID", typeof(int));
            //dt.Columns.Add("Description", typeof(string));
            //dt.Rows.Add(0, null, "Root");
            //dt.Rows.Add(1, 0, "Car");
            //dt.Rows.Add(11, 0, "Truck");
            //dt.Rows.Add(12, 0, "Airplane");
            //dt.Rows.Add(19, 1, "Car Engine");
            //dt.Rows.Add(20, 1, "All Purpose Seat");
            //dt.Rows.Add(21, 19, "Blue Piston");
            //dt.Rows.Add(22, 19, "Bearing Assembly");
            //dt.Rows.Add(23, 21, "Bolt");
            //dt.Rows.Add(24, 22, "Ball Bearing");
            //dt.Rows.Add(25, 20, "Bolt");
            //dt.Rows.Add(26, 20, "Seat Cushion");
            //dt.Rows.Add(27, 26, "Foam");
            //dt.Rows.Add(28, 26, "Grommet");
            //dt.Rows.Add(29, 11, "All Purpose Seat");
            //dt.Rows.Add(30, 11, "Truck Engine");
            //dt.Rows.Add(31, 29, "Bolt");
            //dt.Rows.Add(32, 29, "Seat Cushion");
            //dt.Rows.Add(33, 32, "Foam");
            //dt.Rows.Add(34, 32, "Grommet");
            //dt.Rows.Add(35, 30, "Blue Piston");
            //dt.Rows.Add(36, 30, "Bearing Assembly");
            //dt.Rows.Add(37, 35, "Bolt");
            //dt.Rows.Add(38, 36, "Ball Bearing");
            //dt.Rows.Add(39, 12, "All Purpose Seat");
            //dt.Rows.Add(40, 39, "Bolt");
            //dt.Rows.Add(41, 39, "Seat Cushion");
            //dt.Rows.Add(42, 41, "Foam");
            //dt.Rows.Add(43, 42, "Grommet");
            //ds.Tables.Add(dt);
            dt = this.getData().Result;
            ds.Relations.Add("rsParentChild", ds.Tables["Treetbl"].Columns["ID"], ds.Tables["Treetbl"].Columns["ParentID"]);
            foreach(DataRow rootDir in ds.Tables[0].Rows)
            {
                TreeNode parentNode = new TreeNode();
                parentNode.Text = rootDir["Description"].ToString();
                DataRow[] childrw = rootDir.GetChildRows("rsParentChild");
                foreach(DataRow ChildDir1 in childrw)
                {
                    TreeNode ChildNode = new TreeNode();
                    ChildNode.Text = ChildDir1["Description"].ToString();
                    DataRow[] nestedrows1 = ChildDir1.GetChildRows("rsParentChild");
                    if (nestedrows1.Length > 0)
                    {
                        foreach(DataRow ChildDir2 in nestedrows1)
                        {
                            TreeNode nestedChilds1 = new TreeNode();
                            nestedChilds1.Text = ChildDir2["Description"].ToString();
                            DataRow[] nestedrows2 = ChildDir2.GetChildRows("rsParentChild");
                            if (nestedrows2.Length > 0)
                            {
                                foreach (DataRow ChildDir3 in nestedrows2)
                                {
                                    TreeNode nestedChilds2 = new TreeNode();
                                    nestedChilds2.Text = ChildDir3["Description"].ToString();
                                    nestedChilds1.Nodes.Add(nestedChilds2);
                                }

                            }
                            ChildNode.Nodes.Add(nestedChilds1);  
                        }
                    }
                    parentNode.Nodes.Add(ChildNode);
                }
                this.treeView1.Nodes.Add(parentNode);
            }

        }
        public async Task<DataTable> getData()
        {  
            DataTable dt = null;
            using (var client = new HttpClient())
            {
                //Passing service base url
                client.BaseAddress = new Uri("http://localhost:28934/");
                client.DefaultRequestHeaders.Clear();
                //Define request data format
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                //Sending request to find web api REST service resource GetAllEmployees using HttpClient
                HttpResponseMessage Res = await client.GetAsync("api/values/tableInfo").ConfigureAwait(false);
                //Checking the response is successful or not which is sent using HttpClient
                if (Res.IsSuccessStatusCode)
                {
                    //Storing the response details recieved from web api
                    var Response = Res.Content.ReadAsStringAsync().Result;
                    //Deserializing the response recieved from web api and storing into the Employee list
                    dt = JsonConvert.DeserializeObject<DataTable>(Response);
                }
                return dt;
            }

        }
    }
}
