﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data;
using Newtonsoft.Json;
using System.Net.Http;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace WebApplication1.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class TreeviewController : ControllerBase
    {
        [HttpGet]
        public IActionResult  tableInfo()
        {
            HttpResponseMessage Result = null;
            try
            {
                DataTable dt = new DataTable("Treetbl");
                DataSet ds = new DataSet();
                dt.Columns.Add("ID", typeof(int));
                dt.Columns.Add("ParentID", typeof(int));
                dt.Columns.Add("Description", typeof(string));
                dt.Rows.Add(0, null, "Root");
                dt.Rows.Add(1, 0, "Car");
                dt.Rows.Add(11, 0, "Truck");
                dt.Rows.Add(12, 0, "Airplane");
                dt.Rows.Add(19, 1, "Car Engine");
                dt.Rows.Add(20, 1, "All Purpose Seat");
                dt.Rows.Add(21, 19, "Blue Piston");
                dt.Rows.Add(22, 19, "Bearing Assembly");
                dt.Rows.Add(23, 21, "Bolt");
                dt.Rows.Add(24, 22, "Ball Bearing");
                dt.Rows.Add(25, 20, "Bolt");
                dt.Rows.Add(26, 20, "Seat Cushion");
                dt.Rows.Add(27, 26, "Foam");
                dt.Rows.Add(28, 26, "Grommet");
                dt.Rows.Add(29, 11, "All Purpose Seat");
                dt.Rows.Add(30, 11, "Truck Engine");
                dt.Rows.Add(31, 29, "Bolt");
                dt.Rows.Add(32, 29, "Seat Cushion");
                dt.Rows.Add(33, 32, "Foam");
                dt.Rows.Add(34, 32, "Grommet");
                dt.Rows.Add(35, 30, "Blue Piston");
                dt.Rows.Add(36, 30, "Bearing Assembly");
                dt.Rows.Add(37, 35, "Bolt");
                dt.Rows.Add(38, 36, "Ball Bearing");
                dt.Rows.Add(39, 12, "All Purpose Seat");
                dt.Rows.Add(40, 39, "Bolt");
                dt.Rows.Add(41, 39, "Seat Cushion");
                dt.Rows.Add(42, 41, "Foam");
                dt.Rows.Add(43, 42, "Grommet");
                Result = new HttpResponseMessage() { StatusCode = System.Net.HttpStatusCode.OK, Content = new StringContent(JsonConvert.SerializeObject(dt)) };
            }
            catch(Exception ex)
            {
                Result = new HttpResponseMessage() { StatusCode = System.Net.HttpStatusCode.BadGateway, Content = new StringContent(JsonConvert.SerializeObject(ex.Message)) };
            }
            return Ok(Result.Content.ReadAsStringAsync().Result);
        }
    }
}
