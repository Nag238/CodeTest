﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace WinFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            DataTable dt = null;
            DataSet ds = new DataSet();
            try
            {
                dt = this.getData().Result;
                ds.Tables.Add(dt);
                ds.Relations.Add("rsParentChild", ds.Tables["Table1"].Columns["ID"], ds.Tables["Table1"].Columns["ParentID"]);
                foreach (DataRow rootDir in ds.Tables[0].Rows)
                {
                    TreeNode parentNode = new TreeNode();
                    parentNode.Text = rootDir["Description"].ToString();
                    DataRow[] childrw = rootDir.GetChildRows("rsParentChild");
                    foreach (DataRow ChildDir1 in childrw)
                    {
                        TreeNode ChildNode = new TreeNode();
                        ChildNode.Text = ChildDir1["Description"].ToString();
                        DataRow[] nestedrows1 = ChildDir1.GetChildRows("rsParentChild");
                        if (nestedrows1.Length > 0)
                        {
                            foreach (DataRow ChildDir2 in nestedrows1)
                            {
                                TreeNode nestedChilds1 = new TreeNode();
                                nestedChilds1.Text = ChildDir2["Description"].ToString();
                                DataRow[] nestedrows2 = ChildDir2.GetChildRows("rsParentChild");
                                if (nestedrows2.Length > 0)
                                {
                                    foreach (DataRow ChildDir3 in nestedrows2)
                                    {
                                        TreeNode nestedChilds2 = new TreeNode();
                                        nestedChilds2.Text = ChildDir3["Description"].ToString();
                                        nestedChilds1.Nodes.Add(nestedChilds2);
                                    }

                                }
                                ChildNode.Nodes.Add(nestedChilds1);
                            }
                        }
                        parentNode.Nodes.Add(ChildNode);
                    }
                    this.treeView1.Nodes.Add(parentNode);
                }
            }
            catch(Exception ex)
            {
                throw new Exception(string.Format("Error Parsing Column Name : {0}", ex.Message));
            }
        }

        public async Task<DataTable> getData()
        {
            DataTable dt = null;
            using (var client = new HttpClient())
            {
                try
                {
                    client.BaseAddress = new Uri("http://localhost:28934/");
                    client.DefaultRequestHeaders.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    HttpResponseMessage Res = await client.GetAsync("api/Treeview/tableInfo").ConfigureAwait(false);
                    if (Res.IsSuccessStatusCode)
                    {
                        var Response = Res.Content.ReadAsStringAsync().Result;
                        dt = this.JsonStringToDataTable(Response);
                    }
                }
                catch(Exception ex)
                {
                    throw new Exception(string.Format("getData API failed : {0}", ex.Message));
                }
                return dt;
            }

        }

        public DataTable JsonStringToDataTable(string jsonString)
        {
            DataTable dt = new DataTable();
            try
            {
                string[] jsonStringArray = Regex.Split(jsonString.Replace("[", "").Replace("]", ""), "},{");
                List<string> ColumnsName = new List<string>();
                foreach (string jSA in jsonStringArray)
                {
                    string[] jsonStringData = Regex.Split(jSA.Replace("{", "").Replace("}", ""), ",");
                    foreach (string ColumnsNameData in jsonStringData)
                    {
                        try
                        {
                            int idx = ColumnsNameData.IndexOf(":");
                            string ColumnsNameString = ColumnsNameData.Substring(0, idx - 1).Replace("\"", "").Replace("\"", "").Replace("\\", "");
                            ColumnsNameString = ColumnsNameString != "null" ? ColumnsNameString : "0";
                            if (!ColumnsName.Contains(ColumnsNameString))
                            {
                                ColumnsName.Add(ColumnsNameString);
                            }
                        }
                        catch (Exception ex)
                        {
                            throw new Exception(string.Format("Error Parsing Column Name : {0}", ColumnsNameData));
                        }
                    }
                    break;
                }
                foreach (string AddColumnName in ColumnsName)
                {
                    dt.Columns.Add(AddColumnName);
                }
                foreach (string jSA in jsonStringArray)
                {
                    string[] RowData = Regex.Split(jSA.Replace("{", "").Replace("}", ""), ",");
                    DataRow nr = dt.NewRow();
                    foreach (string rowData in RowData)
                    {
                        try
                        {
                            int idx = rowData.IndexOf(":");
                            string RowColumns = rowData.Substring(0, idx - 1).Replace("\"", "").Replace("\\", "");
                            string RowDataString = rowData.Substring(idx + 1).Replace("\"", "").Replace("\\", "");
                            string data = RowDataString != "null" ? RowDataString : "0";
                            nr[RowColumns] = data;
                        }
                        catch (Exception ex)
                        {
                            throw new Exception(string.Format("Error Parsing Column Data Value : {0}", ex.Message));
                        }
                    }
                    dt.Rows.Add(nr);
                }
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format("Error iin JsonStringToDataTable function : {0}", ex.Message));
            }
            return dt;
        }
    }
}

