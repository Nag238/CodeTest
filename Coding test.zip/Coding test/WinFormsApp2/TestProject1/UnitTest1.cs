using System;
using Xunit;
using WinFormsApp2;
using System.Data;

namespace TestProject1
{
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        {
            DataTable dt = new DataTable();
            Form1 form = new Form1();
            dt = form.getData().Result;
            Assert.NotNull(dt);
        }
    }
}
